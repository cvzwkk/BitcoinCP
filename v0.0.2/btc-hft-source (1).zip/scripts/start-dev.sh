#!/bin/bash
# Start API server (port 8000) + Vite dev server (port 5000) for the BTC HFT app.
set -e

cleanup() {
  if [ -n "$API_PID" ] && kill -0 "$API_PID" 2>/dev/null; then
    kill "$API_PID" 2>/dev/null || true
  fi
  if [ -n "$WEB_PID" ] && kill -0 "$WEB_PID" 2>/dev/null; then
    kill "$WEB_PID" 2>/dev/null || true
  fi
}
trap cleanup EXIT INT TERM

echo "[boot] building api-server..."
pnpm --filter @workspace/api-server run build

echo "[boot] starting api-server on :8000..."
NODE_ENV=development PORT=8000 \
  node --enable-source-maps ./artifacts/api-server/dist/index.mjs &
API_PID=$!

# Wait briefly for api-server to start listening before launching the proxy
for i in $(seq 1 30); do
  if (echo > /dev/tcp/127.0.0.1/8000) 2>/dev/null; then
    echo "[boot] api-server ready on :8000"
    break
  fi
  sleep 0.5
done

echo "[boot] starting frontend on :5000..."
PORT=5000 BASE_PATH=/ \
  pnpm --filter @workspace/hft-btc run dev &
WEB_PID=$!

wait -n "$API_PID" "$WEB_PID"
EXIT_CODE=$?
echo "[boot] one of the processes exited (code=$EXIT_CODE), shutting down"
exit $EXIT_CODE
