import {
  useGetChartForecast,
  getGetChartForecastQueryKey,
  type ChartPrediction,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Cell,
} from "recharts";
import {
  BarChart3,
  TrendingUp,
  TrendingDown,
  Minus,
  Loader2,
  Activity,
  Hourglass,
} from "lucide-react";
import { format } from "date-fns";

const COLOR_UP = "#10b981";
const COLOR_DOWN = "#f43f5e";
const COLOR_FLAT = "#64748b";

function dirColor(dir: ChartPrediction["direction"]): string {
  if (dir === "up") return COLOR_UP;
  if (dir === "down") return COLOR_DOWN;
  return COLOR_FLAT;
}

function dirIcon(dir: ChartPrediction["direction"]) {
  if (dir === "up") return <TrendingUp className="w-3.5 h-3.5" />;
  if (dir === "down") return <TrendingDown className="w-3.5 h-3.5" />;
  return <Minus className="w-3.5 h-3.5" />;
}

function pct(n: number) {
  return (n * 100).toFixed(1) + "%";
}

function fmtPrice(n: number) {
  if (!n) return "—";
  return n.toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

export function ChartForecastTab() {
  const { data, isLoading } = useGetChartForecast({
    query: {
      refetchInterval: 1000,
      queryKey: getGetChartForecastQueryKey(),
    },
  });

  if (isLoading || !data) {
    return (
      <div className="flex items-center justify-center p-12 text-muted-foreground">
        <Loader2 className="w-6 h-6 animate-spin mr-2" /> Building multi-timeframe
        forecast…
      </div>
    );
  }

  const chartData = data.predictions.map((p) => ({
    label: p.label,
    deltaBps: Number(p.deltaBps.toFixed(2)),
    direction: p.direction,
    confidence: p.confidence,
  }));

  return (
    <div className="space-y-6">
      <Card className="bg-card/60 border-border/40">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-sm uppercase tracking-widest font-mono flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-primary" />
            Multi-Timeframe Forecast
          </CardTitle>
          <Badge variant="outline" className="font-mono text-[10px]">
            updated {format(new Date(data.updatedAt), "HH:mm:ss")}
          </Badge>
        </CardHeader>
        <CardContent>
          <div className="h-[260px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" />
                <XAxis dataKey="label" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" tickFormatter={(v) => `${v} bps`} />
                <Tooltip
                  contentStyle={{
                    background: "rgba(17,24,39,0.96)",
                    borderRadius: 8,
                    border: "1px solid rgba(255,255,255,0.1)",
                    fontSize: 12,
                  }}
                  formatter={(value: number, _name, ctx) => [
                    `${value.toFixed(2)} bps (${pct(
                      (ctx.payload as { confidence: number }).confidence,
                    )})`,
                    "Predicted move",
                  ]}
                />
                <Bar dataKey="deltaBps" radius={[6, 6, 0, 0]}>
                  {chartData.map((entry, idx) => (
                    <Cell key={`c-${idx}`} fill={dirColor(entry.direction)} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {data.predictions.map((p) => (
          <Card
            key={p.label}
            className="bg-card/60 border-border/40 hover:border-primary/40 transition-colors"
          >
            <CardHeader className="pb-2 flex flex-row items-center justify-between">
              <CardTitle className="text-xs uppercase tracking-widest font-mono flex items-center gap-2">
                <Activity className="w-3.5 h-3.5 text-primary" />
                {p.label}
              </CardTitle>
              <Badge
                variant="outline"
                className="font-mono text-[10px] gap-1 px-2"
                style={{ color: dirColor(p.direction), borderColor: dirColor(p.direction) }}
              >
                {dirIcon(p.direction)}
                {p.signal}
              </Badge>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-baseline justify-between font-mono">
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
                    Now
                  </div>
                  <div className="text-base">${fmtPrice(p.currentPrice)}</div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
                    Forecast
                  </div>
                  <div
                    className="text-base"
                    style={{ color: dirColor(p.direction) }}
                  >
                    ${fmtPrice(p.predictedPrice)}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 text-[10px] font-mono">
                <div>
                  <div className="text-muted-foreground uppercase">Δ bps</div>
                  <div style={{ color: dirColor(p.direction) }}>
                    {p.deltaBps >= 0 ? "+" : ""}
                    {p.deltaBps.toFixed(2)}
                  </div>
                </div>
                <div>
                  <div className="text-muted-foreground uppercase">Conf</div>
                  <div className="text-foreground">{pct(p.confidence)}</div>
                </div>
                <div>
                  <div className="text-muted-foreground uppercase">Bars</div>
                  <div className="text-foreground">{p.candleCount}</div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-[10px] font-mono text-muted-foreground">
                <div>RSI14 <span className="text-foreground">{p.indicators.rsi14.toFixed(1)}</span></div>
                <div>ATR <span className="text-foreground">{p.indicators.atrBps.toFixed(1)} bps</span></div>
                <div>MACD <span className="text-foreground">{p.indicators.macdHist.toFixed(2)}</span></div>
                <div>Slope <span className="text-foreground">{p.indicators.slopeBpsPerBar.toFixed(2)}</span></div>
              </div>

              <div className="text-[10px] font-mono text-muted-foreground space-y-0.5 border-t border-border/40 pt-2 max-h-24 overflow-y-auto">
                {p.reasons.slice(0, 4).map((r, i) => (
                  <div key={i} className="flex gap-1">
                    <span className="text-primary">›</span>
                    <span>{r}</span>
                  </div>
                ))}
              </div>

              <div className="flex items-center gap-1.5 text-[10px] font-mono text-muted-foreground border-t border-border/40 pt-2">
                <Hourglass className="w-3 h-3" />
                resolves {format(new Date(p.resolvesAt), "MMM d HH:mm")}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
