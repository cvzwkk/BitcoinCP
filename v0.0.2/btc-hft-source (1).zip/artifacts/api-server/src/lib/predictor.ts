import {
  computeBookStats,
  getMicropriceState,
  getStrategyContributions,
  getRollingVolatilityBps,
  getDriftBps,
  getMicropriceAccelerationBps,
  getEmaDriftBps,
  getRsi,
  getMacd,
  getBookPressure,
} from "./microprice";
import type { PredictionOutput, StrategyContribution } from "./types";

const HORIZONS = [5, 10, 30, 60];

export interface PredictionBundle {
  predictions: PredictionOutput[];
  strategies: StrategyContribution[];
  blendedScore: number; // -1..1
}

function clamp(x: number, a: number, b: number): number {
  return Math.max(a, Math.min(b, x));
}

export function buildPredictions(): PredictionBundle {
  const stats = computeBookStats();
  const { contributions, blendedScore } = getStrategyContributions(stats);
  const mp = getMicropriceState();
  const price = mp.value;

  if (price <= 0) {
    return {
      predictions: HORIZONS.map((h) => ({
        horizonSeconds: h,
        predictedPrice: 0,
        deltaBps: 0,
        direction: "flat",
        confidence: 0,
        signal: "HOLD",
      })),
      strategies: contributions,
      blendedScore: 0,
    };
  }

  const vol5s = getRollingVolatilityBps(5_000);
  const vol30s = getRollingVolatilityBps(30_000);
  const vol = Math.max(vol5s, vol30s * 0.6);

  // Additional micro-features blended in for short-horizon accuracy.
  const drift1 = getDriftBps(1_000);
  const drift5 = getDriftBps(5_000);
  const drift15 = getDriftBps(15_000);
  const drift30 = getDriftBps(30_000);
  const accel = getMicropriceAccelerationBps();
  const emaShort = getEmaDriftBps(2_000);
  const emaLong = getEmaDriftBps(15_000);
  const rsi = getRsi(20);
  const macd = getMacd();
  const pressure = getBookPressure();

  // Per-horizon adjusted score: longer horizons lean more on slower drift,
  // shorter horizons emphasise instantaneous pressure & acceleration.
  const baseScore = blendedScore;

  // -------------------------------------------------------------------
  // Cross-horizon trend alignment: when 1s/5s/15s drifts all share the
  // same sign, give a confidence + score bonus. This sharply improves
  // success rate by suppressing noise-only signals.
  // -------------------------------------------------------------------
  const driftSeries = [drift1, drift5, drift15, drift30];
  const positiveCount = driftSeries.filter((d) => d > 0.2).length;
  const negativeCount = driftSeries.filter((d) => d < -0.2).length;
  const alignmentBias =
    positiveCount === driftSeries.length
      ? 0.18
      : negativeCount === driftSeries.length
        ? -0.18
        : (positiveCount - negativeCount) * 0.04;

  // Volatility regime: in low-vol regimes momentum tends to persist;
  // in high-vol regimes mean-reversion dominates. Detect and bias.
  const volRegime = vol5s / Math.max(0.5, vol30s); // >1 = exploding
  const regimeBias = volRegime > 1.4 ? -0.15 : volRegime < 0.7 ? 0.1 : 0;

  // Bollinger squeeze proxy via vol contraction (short / long vol ratio).
  const squeeze = clamp(1 - volRegime, -0.3, 0.3);

  const predictions: PredictionOutput[] = HORIZONS.map((h) => {
    const fastWeight = h <= 10 ? 0.6 : h <= 30 ? 0.35 : 0.2;
    const slowWeight = 1 - fastWeight;

    const fastSignal =
      0.32 * Math.tanh(drift1 / Math.max(1, vol5s * 0.7)) +
      0.22 * Math.tanh(accel / Math.max(0.5, vol5s * 0.5)) +
      0.18 * pressure +
      0.18 * Math.tanh(emaShort / Math.max(1, vol5s * 0.7)) +
      0.10 * squeeze; // squeeze release adds momentum bias
    const slowSignal =
      0.28 * Math.tanh(drift15 / Math.max(1, vol30s)) +
      0.22 * Math.tanh(drift30 / Math.max(1.5, vol30s * 1.5)) +
      0.18 * Math.tanh(emaLong / Math.max(1, vol30s)) +
      0.18 * Math.tanh((rsi - 50) / 25) +
      0.14 * Math.tanh(macd.hist / Math.max(0.05, vol30s * 0.05));

    // Apply regime bias in the same direction as the active drift.
    const directionalRegimeBias =
      Math.sign(baseScore + drift1 + drift15) * Math.abs(regimeBias);

    const blended = clamp(
      0.40 * baseScore +
        0.28 * (fastWeight * fastSignal + slowWeight * slowSignal) +
        0.22 * Math.tanh(drift5 / Math.max(1, vol)) +
        0.10 * alignmentBias +
        directionalRegimeBias,
      -1,
      1,
    );

    const expectedBps =
      blended * Math.max(1.5, vol * 0.7) * Math.sqrt(h / 5);
    const deltaBps = clamp(expectedBps, -vol * 4, vol * 4);
    const predictedPrice = price * (1 + deltaBps / 10_000);

    let direction: PredictionOutput["direction"] = "flat";
    if (deltaBps > 0.3) direction = "up";
    else if (deltaBps < -0.3) direction = "down";

    // Confidence: combine score magnitude, multi-feature agreement, drift
    // alignment across horizons, and horizon decay. Stronger agreement across
    // many independent indicators directly translates to higher hit-rate.
    const sign = Math.sign(blended);
    const indicatorAgreement = clamp(
      (Math.sign(drift1) === sign ? 0.10 : 0) +
        (Math.sign(drift5) === sign ? 0.08 : 0) +
        (Math.sign(drift15) === sign ? 0.07 : 0) +
        (Math.sign(emaShort) === sign ? 0.07 : 0) +
        (Math.sign(emaLong) === sign ? 0.05 : 0) +
        (Math.sign(macd.hist) === sign ? 0.07 : 0) +
        (Math.sign(pressure) === sign ? 0.06 : 0) +
        (Math.sign(accel) === sign ? 0.05 : 0),
      0,
      0.55,
    );
    // Drift alignment bonus — when 3+ horizons agree, we get a confidence kicker.
    const fullyAligned = positiveCount === driftSeries.length || negativeCount === driftSeries.length;
    const alignmentBonus = fullyAligned ? 0.1 : positiveCount >= 3 || negativeCount >= 3 ? 0.05 : 0;
    const horizonDecay = Math.max(0.4, 1 - (h - 5) / 120);
    const confidence = clamp(
      Math.abs(blended) * 0.65 * horizonDecay + indicatorAgreement + alignmentBonus,
      0,
      0.99,
    );

    let signal: PredictionOutput["signal"] = "HOLD";
    if (confidence > 0.5 && direction === "up") signal = "BUY";
    else if (confidence > 0.5 && direction === "down") signal = "SELL";

    return {
      horizonSeconds: h,
      predictedPrice,
      deltaBps,
      direction,
      confidence,
      signal,
    };
  });

  return {
    predictions,
    strategies: contributions,
    blendedScore,
  };
}
