import { logger } from "./logger";
import {
  getMicropriceState,
  getTickHistory,
  getRollingVolatilityBps,
  getDriftBps,
  getEmaDriftBps,
  getRsi,
  getMacd,
} from "./microprice";

// ---------------------------------------------------------------------------
// Multi-timeframe chart predictor
//
// Generates synthetic OHLC candles by aggregating the rolling microprice
// tick stream into bars of the configured interval, then runs a bag of
// classic technical indicators (SMA, EMA9/21/50, RSI14, MACD, Bollinger
// Bands, ATR, slope) plus our microprice short-horizon drift to produce
// a directional forecast for each chart timeframe.
//
// Confidence is the agreement of the indicator votes weighted by the
// magnitude of the score. A high confidence + decisive direction yields
// a BUY/SELL signal; otherwise HOLD.
// ---------------------------------------------------------------------------

export interface ChartHorizon {
  label: string; // "5m", "1h", "1d" ...
  intervalSeconds: number;
}

export const CHART_HORIZONS: readonly ChartHorizon[] = [
  { label: "5m", intervalSeconds: 5 * 60 },
  { label: "15m", intervalSeconds: 15 * 60 },
  { label: "30m", intervalSeconds: 30 * 60 },
  { label: "1h", intervalSeconds: 60 * 60 },
  { label: "3h", intervalSeconds: 3 * 60 * 60 },
  { label: "1d", intervalSeconds: 24 * 60 * 60 },
  { label: "1w", intervalSeconds: 7 * 24 * 60 * 60 },
  { label: "1mo", intervalSeconds: 30 * 24 * 60 * 60 },
] as const;

export interface ChartIndicators {
  sma20: number;
  ema9: number;
  ema21: number;
  ema50: number;
  rsi14: number;
  macd: number;
  macdSignal: number;
  macdHist: number;
  bbUpper: number;
  bbMiddle: number;
  bbLower: number;
  slopeBpsPerBar: number;
  atrBps: number;
}

export interface ChartPrediction {
  label: string;
  intervalSeconds: number;
  currentPrice: number;
  predictedPrice: number;
  deltaBps: number;
  direction: "up" | "down" | "flat";
  confidence: number;
  signal: "BUY" | "SELL" | "HOLD";
  score: number; // -1..1
  reasons: string[];
  indicators: ChartIndicators;
  candleCount: number;
  resolvesAt: number;
}

export interface ChartForecastBundle {
  updatedAt: number;
  predictions: ChartPrediction[];
}

interface Candle {
  t: number; // bar start ms
  o: number;
  h: number;
  l: number;
  c: number;
}

// One ring-buffer of candles per horizon. We persist them in-process so the
// model warms up over time even though we only have live tick data.
const MAX_CANDLES = 240;
const CANDLE_HISTORY = new Map<number, Candle[]>();
for (const h of CHART_HORIZONS) CANDLE_HISTORY.set(h.intervalSeconds, []);

function clamp(x: number, a: number, b: number): number {
  return Math.max(a, Math.min(b, x));
}

function pushTickIntoCandle(intervalSeconds: number, price: number, ts: number) {
  const bucket = Math.floor(ts / 1000 / intervalSeconds) * intervalSeconds * 1000;
  const arr = CANDLE_HISTORY.get(intervalSeconds);
  if (!arr) return;
  const last = arr[arr.length - 1];
  if (last && last.t === bucket) {
    last.c = price;
    if (price > last.h) last.h = price;
    if (price < last.l) last.l = price;
  } else {
    arr.push({ t: bucket, o: price, h: price, l: price, c: price });
    if (arr.length > MAX_CANDLES) arr.splice(0, arr.length - MAX_CANDLES);
  }
}

function seedCandlesFromHistory() {
  const ticks = getTickHistory();
  if (!ticks.length) return;
  for (const horizon of CHART_HORIZONS) {
    const arr = CANDLE_HISTORY.get(horizon.intervalSeconds);
    if (!arr || arr.length > 0) continue;
    for (const t of ticks) {
      pushTickIntoCandle(horizon.intervalSeconds, t.value, t.ts);
    }
  }
}

// ---------- Indicator math ----------
function sma(values: number[], period: number): number {
  if (values.length < period) return values.length ? values[values.length - 1] : 0;
  const slice = values.slice(values.length - period);
  return slice.reduce((s, v) => s + v, 0) / slice.length;
}

function ema(values: number[], period: number): number {
  if (!values.length) return 0;
  const k = 2 / (period + 1);
  let e = values[0];
  for (let i = 1; i < values.length; i++) e = values[i] * k + e * (1 - k);
  return e;
}

function emaSeries(values: number[], period: number): number[] {
  if (!values.length) return [];
  const k = 2 / (period + 1);
  const out: number[] = [values[0]];
  for (let i = 1; i < values.length; i++) {
    out.push(values[i] * k + out[i - 1] * (1 - k));
  }
  return out;
}

function rsi(values: number[], period = 14): number {
  if (values.length < period + 1) return 50;
  let gains = 0;
  let losses = 0;
  for (let i = values.length - period; i < values.length; i++) {
    const d = values[i] - values[i - 1];
    if (d >= 0) gains += d;
    else losses += -d;
  }
  if (gains + losses === 0) return 50;
  const rs = gains / Math.max(1e-9, losses);
  return 100 - 100 / (1 + rs);
}

function macd(values: number[]): { macd: number; signal: number; hist: number } {
  if (values.length < 35) return { macd: 0, signal: 0, hist: 0 };
  const ema12 = emaSeries(values, 12);
  const ema26 = emaSeries(values, 26);
  const macdLine: number[] = ema12.map((v, i) => v - ema26[i]);
  const sig = ema(macdLine.slice(-Math.min(macdLine.length, 30)), 9);
  const macdVal = macdLine[macdLine.length - 1];
  return { macd: macdVal, signal: sig, hist: macdVal - sig };
}

function stddev(values: number[], period: number): number {
  if (values.length < period) return 0;
  const slice = values.slice(values.length - period);
  const mean = slice.reduce((s, v) => s + v, 0) / slice.length;
  const variance = slice.reduce((s, v) => s + (v - mean) ** 2, 0) / slice.length;
  return Math.sqrt(variance);
}

function bollinger(values: number[]) {
  const middle = sma(values, 20);
  const sd = stddev(values, 20);
  return {
    upper: middle + sd * 2,
    middle,
    lower: middle - sd * 2,
  };
}

function atrBps(candles: Candle[], period = 14): number {
  if (candles.length < 2) return 0;
  const slice = candles.slice(-Math.min(candles.length, period + 1));
  let sum = 0;
  let n = 0;
  for (let i = 1; i < slice.length; i++) {
    const c = slice[i];
    const prev = slice[i - 1];
    const tr = Math.max(c.h - c.l, Math.abs(c.h - prev.c), Math.abs(c.l - prev.c));
    if (prev.c > 0) {
      sum += (tr / prev.c) * 10_000;
      n++;
    }
  }
  return n ? sum / n : 0;
}

function slopeBpsPerBar(values: number[], lookback = 20): number {
  if (values.length < 2) return 0;
  const slice = values.slice(-Math.min(values.length, lookback));
  const n = slice.length;
  // Simple linear regression slope, expressed in bps per bar.
  let sumX = 0;
  let sumY = 0;
  let sumXY = 0;
  let sumXX = 0;
  for (let i = 0; i < n; i++) {
    sumX += i;
    sumY += slice[i];
    sumXY += i * slice[i];
    sumXX += i * i;
  }
  const denom = n * sumXX - sumX * sumX;
  if (denom === 0) return 0;
  const slopePrice = (n * sumXY - sumX * sumY) / denom;
  const base = slice[slice.length - 1];
  if (base <= 0) return 0;
  return (slopePrice / base) * 10_000;
}

function buildIndicators(candles: Candle[]): ChartIndicators {
  const closes = candles.map((c) => c.c);
  const m = macd(closes);
  const bb = bollinger(closes);
  return {
    sma20: sma(closes, 20),
    ema9: ema(closes.slice(-Math.min(closes.length, 60)), 9),
    ema21: ema(closes.slice(-Math.min(closes.length, 80)), 21),
    ema50: ema(closes.slice(-Math.min(closes.length, 150)), 50),
    rsi14: rsi(closes, 14),
    macd: m.macd,
    macdSignal: m.signal,
    macdHist: m.hist,
    bbUpper: bb.upper,
    bbMiddle: bb.middle,
    bbLower: bb.lower,
    slopeBpsPerBar: slopeBpsPerBar(closes, 20),
    atrBps: atrBps(candles, 14),
  };
}

// ---------------------------------------------------------------------------
// Forecast model — multi-indicator vote with horizon-aware weighting.
// ---------------------------------------------------------------------------
function buildPredictionFor(
  horizon: ChartHorizon,
  candles: Candle[],
  fallbackPrice: number,
): ChartPrediction {
  const reasons: string[] = [];
  const indicators = candles.length
    ? buildIndicators(candles)
    : ({
        sma20: fallbackPrice,
        ema9: fallbackPrice,
        ema21: fallbackPrice,
        ema50: fallbackPrice,
        rsi14: 50,
        macd: 0,
        macdSignal: 0,
        macdHist: 0,
        bbUpper: fallbackPrice,
        bbMiddle: fallbackPrice,
        bbLower: fallbackPrice,
        slopeBpsPerBar: 0,
        atrBps: 0,
      } as ChartIndicators);

  const currentPrice = candles.length ? candles[candles.length - 1].c : fallbackPrice;
  const atr = Math.max(2, indicators.atrBps);

  // Vote 1 — EMA cross & stack. Stronger weight when ema9/21/50 are stacked.
  const stack =
    (indicators.ema9 > indicators.ema21 ? 1 : -1) +
    (indicators.ema21 > indicators.ema50 ? 1 : -1);
  const emaVote = clamp(stack / 2, -1, 1);
  if (Math.abs(stack) === 2) {
    reasons.push(`EMA stack ${stack > 0 ? "bullish" : "bearish"} (9>21>50)`);
  } else if (stack !== 0) {
    reasons.push(`EMA partial ${stack > 0 ? "bullish" : "bearish"} alignment`);
  }

  // Vote 2 — MACD histogram polarity & magnitude.
  const macdVote = clamp(indicators.macdHist / Math.max(0.01, atr * 0.005), -1, 1);
  if (Math.abs(macdVote) > 0.3) {
    reasons.push(`MACD hist ${indicators.macdHist > 0 ? "expanding up" : "expanding down"}`);
  }

  // Vote 3 — RSI tilt.
  const rsiVote = clamp((indicators.rsi14 - 50) / 25, -1, 1);
  if (indicators.rsi14 > 70) reasons.push("RSI overbought (>70)");
  else if (indicators.rsi14 < 30) reasons.push("RSI oversold (<30)");

  // Vote 4 — Bollinger position.
  const bbRange = Math.max(1e-9, indicators.bbUpper - indicators.bbLower);
  const bbPos = clamp((currentPrice - indicators.bbMiddle) / (bbRange / 2), -1.5, 1.5);
  // Mean-revert when extreme, follow when neutral.
  const bbVote = Math.abs(bbPos) > 1 ? clamp(-bbPos, -1, 1) * 0.6 : clamp(bbPos, -1, 1) * 0.4;
  if (bbPos > 1) reasons.push("Above Bollinger upper band — mean-reversion bias");
  if (bbPos < -1) reasons.push("Below Bollinger lower band — mean-reversion bias");

  // Vote 5 — slope of recent closes.
  const slopeVote = clamp(indicators.slopeBpsPerBar / Math.max(2, atr), -1, 1);
  if (Math.abs(slopeVote) > 0.3) {
    reasons.push(
      `Linear slope ${indicators.slopeBpsPerBar.toFixed(1)} bps/bar`,
    );
  }

  // Vote 6 — short-horizon microprice drift, only meaningful for the
  // shorter chart horizons. Decays out by the 1-day frame.
  const driftHorizonMs =
    horizon.intervalSeconds < 3600 ? 30_000 : horizon.intervalSeconds < 86400 ? 60_000 : 120_000;
  const microDrift = getDriftBps(driftHorizonMs);
  const ema30sDrift = getEmaDriftBps(30_000);
  const microVote = clamp(
    (microDrift / Math.max(2, getRollingVolatilityBps(30_000))) * 0.6 +
      (ema30sDrift / Math.max(2, getRollingVolatilityBps(60_000))) * 0.4,
    -1,
    1,
  );
  const microWeight = horizon.intervalSeconds <= 1800 ? 0.35 : horizon.intervalSeconds <= 10800 ? 0.2 : 0.08;
  if (Math.abs(microVote) > 0.3 && microWeight > 0.05) {
    reasons.push(
      `Microprice drift ${microDrift.toFixed(2)} bps over ${(driftHorizonMs / 1000).toFixed(0)}s`,
    );
  }

  // Vote 7 — confirmation from the global RSI/MACD on tick stream.
  const tickRsi = getRsi(20);
  const tickMacd = getMacd();
  const tickVote = clamp((tickRsi - 50) / 30 + Math.tanh(tickMacd.hist / 0.5) * 0.5, -1, 1);

  // Weighted blend — short horizons favour micro features, long horizons
  // favour the chart indicators.
  const wEma = horizon.intervalSeconds <= 3600 ? 0.18 : 0.25;
  const wMacd = horizon.intervalSeconds <= 3600 ? 0.16 : 0.22;
  const wRsi = 0.12;
  const wBb = 0.1;
  const wSlope = horizon.intervalSeconds <= 3600 ? 0.12 : 0.18;
  const wMicro = microWeight;
  const wTick = Math.max(0.04, 0.18 - microWeight);

  const score = clamp(
    emaVote * wEma +
      macdVote * wMacd +
      rsiVote * wRsi +
      bbVote * wBb +
      slopeVote * wSlope +
      microVote * wMicro +
      tickVote * wTick,
    -1,
    1,
  );

  // Confidence = score magnitude + vote agreement bonus.
  const votes = [emaVote, macdVote, rsiVote, slopeVote, microVote, tickVote];
  const sameSign = votes.filter((v) => Math.sign(v) === Math.sign(score) && v !== 0).length;
  const agreement = clamp(sameSign / votes.length, 0, 1);
  const confidence = clamp(Math.abs(score) * 0.65 + agreement * 0.35, 0, 0.99);

  // Expected move sized by ATR and horizon-relative scaling.
  const expectedBps = score * Math.max(8, atr * 1.4) * Math.sqrt(Math.max(1, candles.length / 12));
  const deltaBps = clamp(expectedBps, -atr * 6, atr * 6);
  const predictedPrice = currentPrice * (1 + deltaBps / 10_000);

  let direction: ChartPrediction["direction"] = "flat";
  if (deltaBps > Math.max(1, atr * 0.15)) direction = "up";
  else if (deltaBps < -Math.max(1, atr * 0.15)) direction = "down";

  let signal: ChartPrediction["signal"] = "HOLD";
  if (confidence >= 0.55 && direction === "up") signal = "BUY";
  else if (confidence >= 0.55 && direction === "down") signal = "SELL";

  if (!reasons.length) reasons.push("Insufficient signal — holding.");

  return {
    label: horizon.label,
    intervalSeconds: horizon.intervalSeconds,
    currentPrice,
    predictedPrice,
    deltaBps,
    direction,
    confidence,
    signal,
    score,
    reasons: reasons.slice(0, 6),
    indicators,
    candleCount: candles.length,
    resolvesAt: Date.now() + horizon.intervalSeconds * 1000,
  };
}

let lastBundle: ChartForecastBundle = {
  updatedAt: Date.now(),
  predictions: CHART_HORIZONS.map((h) => ({
    label: h.label,
    intervalSeconds: h.intervalSeconds,
    currentPrice: 0,
    predictedPrice: 0,
    deltaBps: 0,
    direction: "flat" as const,
    confidence: 0,
    signal: "HOLD" as const,
    score: 0,
    reasons: ["Warming up — collecting candle history."],
    indicators: {
      sma20: 0, ema9: 0, ema21: 0, ema50: 0, rsi14: 50,
      macd: 0, macdSignal: 0, macdHist: 0,
      bbUpper: 0, bbMiddle: 0, bbLower: 0,
      slopeBpsPerBar: 0, atrBps: 0,
    },
    candleCount: 0,
    resolvesAt: Date.now() + h.intervalSeconds * 1000,
  })),
};

function recompute(): void {
  const mp = getMicropriceState();
  const price = mp.value;
  if (price <= 0) return;

  // Append latest tick into every horizon bucket.
  for (const horizon of CHART_HORIZONS) {
    pushTickIntoCandle(horizon.intervalSeconds, price, mp.updatedAt || Date.now());
  }

  const predictions = CHART_HORIZONS.map((horizon) => {
    const candles = CANDLE_HISTORY.get(horizon.intervalSeconds) ?? [];
    return buildPredictionFor(horizon, candles, price);
  });

  lastBundle = { updatedAt: Date.now(), predictions };
}

export function getChartPredictions(): ChartForecastBundle {
  return lastBundle;
}

let started = false;
export function startChartPredictorLoop(): void {
  if (started) return;
  started = true;
  // Seed buckets from any history we already have, then recompute on a 1Hz
  // cadence (we only need a single update per second since the largest
  // horizon is monthly).
  setTimeout(() => {
    try {
      seedCandlesFromHistory();
      recompute();
    } catch (err) {
      logger.error({ err }, "chart predictor seed error");
    }
  }, 1500);

  setInterval(() => {
    try {
      recompute();
    } catch (err) {
      logger.error({ err }, "chart predictor recompute error");
    }
  }, 1000);
}
