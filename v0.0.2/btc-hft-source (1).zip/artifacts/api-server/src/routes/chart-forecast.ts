import { Router, type IRouter } from "express";
import { GetChartForecastResponse } from "@workspace/api-zod";
import { getChartPredictions } from "../lib/chart-predictor";

const router: IRouter = Router();

router.get("/chart/forecast", (_req, res) => {
  const bundle = getChartPredictions();
  res.json(GetChartForecastResponse.parse(bundle));
});

export default router;
